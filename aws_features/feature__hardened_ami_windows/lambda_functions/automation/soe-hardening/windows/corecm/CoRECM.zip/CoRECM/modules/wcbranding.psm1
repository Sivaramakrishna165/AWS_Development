# This module will include functions related to SOE Branding
# Author: Harikrishnan GN
# Date  : 17-july-2015
# Updated 11-jul-2016 by Umesh - updated Get-SOEInterfaceMode function to return Nano mode accurately
# updated 20-dec-2017 by Umesh - replaced sbmconfig.xml with buildconfig.xml
# ----------------------------------------------------------------------------------------

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

# ----------------------------------------------------------------------------------------
# This function will Set the Variables for SOE Branding in XML
# ----------------------------------------------------------------------------------------
Function Set-SOEBrandnginXML {
Param(
$SOEBuildXML,
$CategoryName = "CoRE Branding"
)

		#Read the Branding Category
	$SOECategory =  Get-SOEXMLCategory -SOEBuildXML $SOEBuildXML -CategoryName $CategoryName;
	if($SOECategory -ne $Null) {
		#Change the default Value field as neccesary
		forEach($Policy in $SOECategory.Policy) {
			$DefaultValue = $NULL;
			try {
				Switch($Policy.DefaultValue) {
				   {$_.Value.Contains("_BOOTMODE_")} {
						$DefaultValue = Get-SOEBootMode
						$Policy.DefaultValue.Value =  $Policy.DefaultValue.Value  -Replace "_BOOTMODE_",$DefaultValue;
				   }
				   {$_.Value.Contains("_LOADDATETIME_")} {
						$DefaultValue = Get-Date;
						$Policy.DefaultValue.Value =  $Policy.DefaultValue.Value  -Replace "_LOADDATETIME_",$DefaultValue;
				   }
				   {$_.Value.Contains("_OSVERSION_")} {
						$DefaultValue = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name "ProductName").ProductName;#MS Default Key - so key will be present
						$Policy.DefaultValue.Value =  $Policy.DefaultValue.Value  -Replace "_OSVERSION_",$DefaultValue;
				   }
				   {$_.Value.Contains("_OSBUILD_")} {
						$DefaultValue = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name "CurrentVersion").CurrentVersion;#MS Default Key - so key will be present
						$DefaultValue +=  ".$((Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name "CurrentBuildNumber").CurrentBuildNumber)";#MS Default Key - so key will be present
						$Policy.DefaultValue.Value =  $Policy.DefaultValue.Value  -Replace "_OSBUILD_",$DefaultValue;
				   }
				   {$_.Value.Contains("_EDITIONID_")} {
						$DefaultValue = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name "EditionID").EditionID;#MS Default Key - so key will be present
						$Policy.DefaultValue.Value =  $Policy.DefaultValue.Value  -Replace "_EDITIONID_",$DefaultValue;
				   }
				   {$_.Value.Contains("_INTERFACEMODE_")} {
						$DefaultValue = Get-SOEInterfaceMode
						$Policy.DefaultValue.Value =  $Policy.DefaultValue.Value  -Replace "_INTERFACEMODE_",$DefaultValue;
				   }
				   {$_.Value.Contains("_INTERFACETAG_")} {
						$DefaultValue = Get-SOEInterfaceMode -Tag
						$Policy.DefaultValue.Value =  $Policy.DefaultValue.Value  -Replace "_INTERFACETAG_",$DefaultValue;
				   }
					{$_.Value.Contains("_BUILDPURPOSE_")} {
						$DefaultValue = Get-SOEBuildPurpose
						$Policy.DefaultValue.Value =  $Policy.DefaultValue.Value  -Replace "_BUILDPURPOSE_",$DefaultValue;
				   }
				   {$_.Value.Contains("_HARDWAREVENDOR_")} {
						$DefaultValue = Get-SOEVendor
						$Policy.DefaultValue.Value =  $Policy.DefaultValue.Value  -Replace "_HARDWAREVENDOR_",$DefaultValue;
				   }
				   {$_.Value.Contains("_OEMMODEL_")} {
						$DefaultValue = Get-SOEOEMModel
						$Policy.DefaultValue.Value =  $Policy.DefaultValue.Value  -Replace "_OEMMODEL_",$DefaultValue;
				   }
				   default {
				   
				   } 

				}
			}
			catch {}
		}
    }
	return $SOEBuildXML
}
# ----------------------------------------------------------------------------------------
#Function to return s specific Category from XML
# ----------------------------------------------------------------------------------------
Function Get-SOEXMLCategory($SOEBuildXML,$CategoryName) {
    $SOEPolicies = (Get-WCXMLNodes -Xml $SOEBuildXML -XPath "//Category");
    return ($SOEPolicies | Where-Object { $_.Name -eq $CategoryName })
}
# ----------------------------------------------------------------------------------------
#Identify whether the Boot Mode is BIOS or UEFI
# ----------------------------------------------------------------------------------------
Function Get-SOEBootMode {

    #Get the BootMode from buildconfig.xml
    If(Test-Path $env:SystemDrive\SUPPORT\buildconfig.xml) {
        $sbmConfig = [xml](Get-Content $env:SystemDrive\SUPPORT\buildconfig.xml);
        $Mode = $sbmConfig.BuildManager.BootMode;
    }
    
    if($Mode -eq $NULL) {
        try {
                #On a UEFI Machine the below command would output the value or it would say its not defined
                $Res=Get-SecureBootUEFI -Name SetupMode -ErrorAction SilentlyContinue | Out-Null ;
                $Mode = "UEFI"
            }
            Catch {
                    if($_.Exception.Message.ToString() -like "*not supported*") {
                        #Exception message - Get-SecureBootUEFI : Cmdlet not supported on this platform: 0xC0000002
                        $Mode = "BIOS"
                    }
                    else {
                        #Exception Message - Get-SecureBootUefi : Variable is currently undefined: 0xC0000100 
                        $Mode = "UEFI" 
                    }
            }
    }

    if($Mode -eq $Null) { $Mode = "" }
    return $Mode;
}

# ----------------------------------------------------------------------------------------
#Identify whether the Interface Mode ServerCore full or Minshell or Nano
# ----------------------------------------------------------------------------------------
Function Get-SOEInterfaceMode([Switch] $Tag) {

    # get interface mode - method is different for w2k8r2 and w2k12+
    #https://msdn.microsoft.com/en-us/library/hh846315%28v=vs.85%29.aspx -> for w2k12 and above
    if((get-ciminstance -ClassName win32_operatingsystem).Version.startsWith("6.1.")) {
        # this is windows server 2008 R2
		$OSSKU = (get-ciminstance -ClassName win32_operatingsystem).operatingsystemSKU
        #https://msdn.microsoft.com/en-us/library/aa394239(v=vs.85).aspx
        if($OSSKU -in (7,8,10)) { # standard, datacenter, enterprise gui
            $Mode = "Server with a GUI (Full GUI)"    
        }
        elseif($OSSKU -in (12,13,14)) { # standard, datacenter, enterprise core
            $Mode = "Server Core"
        }
        else { $Mode = "Unidentified" }

        # if shortname is needed then return it
        if($Tag.IsPresent) {
		    Switch($Mode) {
			    "Server with a GUI (Full GUI)" { $Mode = ""; }
			    "Server Core" { $Mode = "Core"; }
		    }
	    }
    }
    else { # it is windows servfer 2012 and above
	    $ServerLevels = Get-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Server\ServerLevels"

	    if($ServerLevels.GetValue("NanoServer") -eq "1") { $Mode  = "Nano" }
	    elseif(($ServerLevels.GetValue("Server-Gui-Shell") -eq "1") -and ($ServerLevels.GetValue("Server-Gui-Mgmt") -eq "1")) { $Mode = "Server with a GUI (Full GUI)"; }
	    elseif($ServerLevels.GetValue("Server-Gui-Mgmt") -eq "1") { $Mode = "Minimal Server Interface"; }
	    elseif($ServerLevels.GetValue("ServerCore") -eq "1") { $Mode = "Server Core" }
	
	    if($Tag.IsPresent) {
		    Switch($Mode) {
			    "Server with a GUI (Full GUI)" { $Mode = ""; }
			    "Server Core" { $Mode = "Core"; }
			    "Minimal Server Interface" { $Mode = "Minshell"; }
                # for nano, it will be "Nano" as above
		    }
	    }
    }
	
    return $Mode
}

# ----------------------------------------------------------------------------------------
#Identify BuildPurpose
# ----------------------------------------------------------------------------------------
Function Get-SOEBuildPurpose {
    $Mode = "Modular_Install";
    #Get the BuildPurpose from buildconfig.xml
	
	If((Test-Path -Path "$env:systemdrive\SUPPORT\buildconfig.xml") -and ((Get-ChildItem "$env:systemdrive\SUPPORT" -Directory | Where-Object { $_.Name -Like "BOOT*" }) -ne $NULL)) { 
		$Mode = "Server_Install"
	}
	
    If(Test-Path $env:SystemDrive\SUPPORT\buildconfig.xml) {
        $sbmConfig = [xml](Get-Content $env:SystemDrive\SUPPORT\buildconfig.xml);
        if($sbmConfig.BuildManager.BuildTypeInfo.BuildType -ne "serverinstall") {
            $Mode = "Imaging_Build"
        }
    }
	
    return $Mode
}
# ----------------------------------------------------------------------------------------
#Get Vendor Name
# ----------------------------------------------------------------------------------------
Function Get-SOEVendor {

    $Vendor = ((Get-CimInstance -ClassName "Win32_ComputerSystem" | Select-Object Manufacturer).Manufacturer -split " ")[0];

    if($Vendor -like "*HEWLETT*") {$Vendor = "HPE"}
	elseif($Vendor -like "*HP*") {$Vendor = "HPE"}
	elseif($Vendor -like "*MICROSOFT*") { $Vendor = "HYPERV" }

    return $Vendor;
}
# ----------------------------------------------------------------------------------------
#Build OEM Model
# ----------------------------------------------------------------------------------------
Function Get-SOEOEMModel {
    $OSName = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name "ProductName").ProductName;
    
    if($OSName -like "*STANDARD*") {$OSName = "STD"}
    elseif($OSName -like "*DATACENTER*") {$OSName = "DAT"}
    elseif($OSName -like "*ENTERPRISE*") {$OSName = "ENT"}

	$Interface = Get-SOEInterfaceMode -Tag;
	$OEModel = $OSName;
	if($Interface -ne "") {
		$OEModel = "$OSName $Interface";
	}

    return $OEModel;
}