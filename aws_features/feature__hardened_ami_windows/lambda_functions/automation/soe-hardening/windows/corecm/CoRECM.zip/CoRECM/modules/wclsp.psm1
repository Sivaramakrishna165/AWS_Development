﻿# This script module contains functions related to Local Security Policy (LSP) handling by CoRECM Manager
# Reading/parsing as well as updating local security policy settings are covered in the module
# Author: Umesh Thakur
# Date  : 16-Oct-2014
# Updated: 06-may-2016 by Umesh - replaced Clone() method of XMLNode/XMLElement with CloneNode($true) to support Nano
# Updated: 06-may-2016 by Umesh - replaced New-WCLSPIntrenalStructure function content (xmlTextWriter based xml struct gen) with strongly typed text structure to support nano
# Updated: 06-may-2016 by Umesh - replaced xml .Save($file) method with .Save([system.io.file]::createText($file)) to support nano
# added below two lines to include support for PowerShell common parameters

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

[CmdletBinding()]
Param ()

#region LSPScriptVariables
[string]$DefaultDataType = "string" #default data type for local security policy items
[xml]$PXml = '' # variable to hold local security policy data in XML format. Used for returning Get- queries for given policy
#endregion LSPScriptVariables

#region LSPFunctions
# --------------------------------------------------------------------------------------
# This function will create XML structure to store Local Security Policy
# (settings, values, data type) into XML structure for further query purposes
# note: old function that uses XML to create structure is removed for nano compatibility
# --------------------------------------------------------------------------------------
Function New-WCLSPIntrenalStructure {
[CmdletBinding()]
param()

# This function creates a node in WC LSP node format
Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
$wcLspStruct = @'
<?xml version="1.0"?>
<WCLocalSecurityPolicyInfo>
    <SystemAccess>
        <Policy Name="" Value="" Type="" />
    </SystemAccess>
    <EventAudit>
        <Policy Name="" Value="" Type="" />
    </EventAudit>
    <Kerberos>
        <Policy Name="" Value="" Type="" />
    </Kerberos>
    <RegistryValues>
        <Policy Name="" Value="" Type="" />
    </RegistryValues>
    <PrivilegeRights>
        <Policy Name="" Value="" Type="" />
    </PrivilegeRights>
    <AdvancedAuditPol>
        <Policy Name="" Value="" Type="" />
    </AdvancedAuditPol>
</WCLocalSecurityPolicyInfo>
'@
     # Set the File Name
    [string]$filePath = [System.IO.Path]::GetTempFileName() # get a temporary file path to create LSP strcuture
    Write-WCLog -Level info -Message "Created a temporary file for LSP node structure"
    Write-WCLog -Level debug -Message "Temporary file path is $filePath"

    $wcLspStruct | Out-File -FilePath $filePath -Encoding ascii -Force # write the struct to temp file
    Write-WCLog -Level info -Message "LSP node structure written to $filePath"
    Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    return $filePath # return generated file
}


# --------------------------------------------------------------------------
# This function will export Local Security Policy using SECEDIT command and  
# return the file containing all exported security settings
# --------------------------------------------------------------------------
Function Export-WCLocalSecurityPolicy {
[CmdletBinding()]
param()
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    [string]$tmp = [System.IO.Path]::GetTempFileName() # get a temporary file path to export settings to
    Write-WCLog -Level info -Message "Exporting Local Security Policy to $tmp"
    
    # try to get secedit results with proper error handling
    try { 
        $seResult = secedit.exe /export /cfg $tmp
    }
    catch {
        Write-WCLog -Level error -Message "Error exporting LSP settings to $tmp"
        Write-WCLog -Level error -Message ($Error[0].Exception.Message)
    }

    Write-WCLog -Level info -Message "Exported Local Security Policy to $tmp"
    Write-WCLog -Level debug -Message "messages from secedit:"
    Write-WCLog -Level debug -Message ($seResult -join "`n") # secedit result is an array
    Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    return $tmp
}
 
# -----------------------------------------------------------------------------------------
# This function will return the security settings from given LSP area
# Valid areas are: [System Access], [Event Audit], [Registry Values] and [Privilege Rights]
# [File Security] and [Service General Setting]
# -----------------------------------------------------------------------------------------
Function Get-WCLocalSecurityPolicyArea {
[CmdletBinding()]
param($LSPExportFile, $LSPAreaName)
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    Write-WCLog -Level info -Message "LSP export file given is $LSPExportFile"
    Write-WCLog -Level info -Message "Area to export is $LSPAreaName"
    $lspContent = Get-Content $LSPExportFile #get contents of Local Security Policy export file
    $currentSection = '' #indicate that current item is blank
    # TODO: Use write-debug to show debugging information like variable value in the loop etc.

    $AreaPolicyList = New-Object System.Collections.ArrayList 
    Write-WCLog -Level info -Message "Getting policy details from $LSPAreaName area"

    # Loop through local security policy contents and get those matcing with given LSP area
    $lspContent | foreach {
        if($_.ToString() -eq $lspAreaName) { $currentSection = $lspAreaName} 
        elseif($_.ToString().StartsWith('[')) { $currentSection = '' }
        elseif($currentSection -eq $lspAreaName) { 
            $currItem = $_.ToString()
            $AreaPolicyList.Add($currItem) | Out-Null
        }
    }
    Write-WCLog -Level info -Message "Policy details received, returning it back to the caller"
    Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    return $AreaPolicyList #return list of policies in given LSP area
}

# ---------------------------------------------------------------------------------------------------
# This function will return data type of given LSP area setting, Valid for 'RegistryValues' area only
# ---------------------------------------------------------------------------------------------------
Function Get-WCLSPDataType($LSPAreaName, $PolicyLine) {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
    $dataTypes = @{ "1" = "REG_SZ"; "2" = "REG_EXPAND_SZ"; "3" = "REG_BINARY"; "4" = "REG_DWORD"; "7" = "REG_MULTI_SZ" }
    
    # this parsing has to be done only for RegistryValues area
    Write-WCLog -Level debug -Message "Given area name is $LSPAreaName"
    if($LSPAreaName -eq "RegistryValues") {
        Write-WCLog -Level debug -Message "Processing policy item:"
        Write-WCLog -Level debug -Message $PolicyLine

        $plArray = $PolicyLine.split("=") #split into an array
        if($plArray.count -eq 2) { #valid policy line
            Write-WCLog -Level debug -Message "A valid policy item has been specified, processing it"
            $pvArray = $plArray[1].Split(",") #split the value portion to get datatype (datatype,value)
            if([System.String]::IsNullOrEmpty($dataTypes[$pvArray[0]])) { 
                Write-WCLog -Level debug -Message "Data type is blank or not found for given policy item"
                Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
                return "" #return empty string
            } 
            else { 
                Write-WCLog -Level debug -Message "Found valid data type for current policy item, returning it to caller"
                Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
                return $dataTypes[$pvArray[0]] 
            } # return identified data type
        }
    }
    else { 
        Write-WCLog -Level debug -Message "Given area is not registryValues, returning default data type to caller"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $script:DefaultDataType 
    } # other than 'RegistryValues', all are string
}

# -----------------------------------------------------------------------------------
# This function will return value of given LSP policy (from RegistryValues type only)
# -----------------------------------------------------------------------------------
Function Get-WCLSPRegistryValue($LSPAreaName, $PolicyLine) {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
    # For RegistryValues area policy, logic is different than others
    Write-WCLog -Level debug -Message "Given area name is $LSPAreaName"
    if($LSPAreaName -eq "RegistryValues") {
        $plArray = $PolicyLine.split("=") #split into an array
        if($plArray.count -eq 2) { #valid policy line
            Write-WCLog -Level debug -Message "A valid policy item has been specified, processing it"
            $pvArray = $plArray[1].Split(",") #split the value portion to get datatype (datatype,value)
            if([System.String]::IsNullOrEmpty($pvArray[1])) { 
                Write-WCLog -Level debug -Message "returning blank value"
                Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
                return "" #return empty string
            } 
            # return registry value. if it is 7(reg_multi_sz) then $pvArray[1..max] will be returned after joining with comma
            else { 
                $pv = ($pvArray[1..($pvArray.count)] -join ",").trim() 
                Write-WCLog -Level debug -Message "returning identified policy value $pv"
                Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
                return $pv
            } # return identified Value, removing double quotes
        }
    } 
    # do not process other than 'RegistryValues'
}

# ----------------------------------------------------------------------------
# This function will Convert security policy from different areas of Local 
# Security Policy into WC Internal Node structure for lookup/reference 
# ----------------------------------------------------------------------------
Function Convert-WCLSPAreaToXML {
[CmdletBinding()]
param($LSPData, [string]$WCLSPStructureFile, [string]$LSPAreaName)
    # Note: $LSPAreaName value MUST match the node name in XML file $WCLSPStructureFile
    # Note: Format: $xml.WCLocalSecurityPolicyInfo.$LSPAreaName.Policy

    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
    Write-WCLog -Level info -Message "LSP area to export is $LSPAreaName"
    Write-WCLog -Level info -Message "Reading LSP node structure file $WCLSPStructureFile"
    
    # Read contents of node structure file in XML format
    [XML]$xml = Get-Content $WCLSPStructureFile
    Write-WCLog -Level debug -Message "Read LSP node structure file into a variable"
    
    # loop thru the LSP data for given area
    Write-WCLog -Level debug -Message "Looping thru all policies identified in $LSPAreaName area"
    foreach($currentPolicy in $LSPData) {
        Write-WCLog -Level debug -Message "Cloning $LSPAreaName policy node"
        # use @() to get an array.. to ensure we can index into [0] even if Policy area is empty
        $clNode = @($xml.WCLocalSecurityPolicyInfo.$LSPAreaName.Policy)[0].CloneNode($true) 
        
        Write-WCLog -Level debug -Message "Processing: $currentPolicy"
        $cpSplit = $currentPolicy.split("=") #split current policy that is in name=value format
        
        #not a valid policy line, log message and continue with next policy item
        if($cpSplit.count -ne 2) { 
            Write-WCLog -Level debug -Message "Current policy is not in valid format. Policy line is:"
            Write-WCLog -Level debug -Message $currentPolicy
        }
        else { # valid policy line, process it and add into xml; consider refactoring the code
            Write-WCLog -Level debug -Message "This is a valid policy line"
            $clNode.Name = $cpSplit[0].trim() # policy name, remove blanks
            if($LSPAreaName -eq 'RegistryValues') {
                $clNode.Value = Get-WCLSPRegistryValue -LSPAreaName $LSPAreaName -PolicyLine $currentPolicy
                Write-WCLog -Level debug -Message "Set policy value as $($clNode.Value)"
            }
            else { 
                $clNode.Value = $cpSplit[1].trim() # remove double quotes and spaces from values
                Write-WCLog -Level debug -Message "Set policy value as $($clNode.Value)"
            } # policy value, remove blanks

            $clNode.Type = Get-WCLSPDataType -LSPAreaName $LSPAreaName -PolicyLine $currentPolicy # Its always string except data in RegistryValues LSP area
            Write-WCLog -Level debug -Message "Set policy data type as $($clNode.Type)"
            $xml.WCLocalSecurityPolicyInfo.$LSPAreaName.AppendChild($clNode) | Out-Null
            Write-WCLog -Level debug -Message "Appended this policy to xml variable"
        }
    }
    # remove blank node that was used for cloning purpose
    if($xml.WCLocalSecurityPolicyInfo.$LSPAreaName.Policy.Count -gt 0) {
        Write-WCLog -Level debug -Message "Removing blank policy node used for cloning purposes"
        $xml.WCLocalSecurityPolicyInfo.$LSPAreaName.RemoveChild($xml.WCLocalSecurityPolicyInfo.$LSPAreaName.Policy[0]) | Out-Null
    }

    # done processing, return the updated xml data back
    Write-WCLog -Level info -Message "Processing of $LSPAreaName area complete"
    Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
    return $xml
}
#endregion LSPFunctions


#region LSPPolicyReaderFunctions
# -----------------------------------------------------------------------------
# This function will test if variable holding policies XML data is valid or not
# -----------------------------------------------------------------------------
Function Test-WCLSPXMLVariable {
    if($Script:PXml.WCLocalSecurityPolicyInfo -eq $null) { #Policies XML variable not populated
        return $false
    } else { return $true }
}

# -----------------------------------------------------------------------------
# This function will read WC LSP Policies file into script variable after all
# LSP policies have been read by calling respective functions
# -----------------------------------------------------------------------------
Function Set-WCLSPXMLVariable([string]$PolicyXMLFile) {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    try {
        [xml]$Script:PXml = Get-Content $PolicyXMLFile -ErrorAction Stop
        Write-WCLog -Level info -Message "Successfuly read policies xml file into script variable for lookup"
    }
    catch {
        Write-WCLog -Level error -Message "Error reading policies xml file into script variable"
        Write-WCLog -Level error -LogLine ($_.Exception.Message)
    }
    Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
}

# --------------------------------------------------------------------------------
# This function will return System Access Policy based on given policy name string
# --------------------------------------------------------------------------------
Function Get-WCLSPSystemAccessPolicy([string]$PolicyName) {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
    if(-not (Test-WCLSPXMLVariable)) {
        Write-WCLog -Level debug -Message "LSP XML data not generated. Cannot get policy value"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $null
    }

    $pol = $Script:PXml.WCLocalSecurityPolicyInfo.SystemAccess.policy | where {$_.Name -eq $PolicyName}
    Write-WCLog -Level debug -Message "Value for policy $PolicyName is $pol"
    
    if($pol.count -eq 0) { 
        Write-WCLog -Level debug -Message "Policy $PolicyName, policy not found in xml"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $null 
    } 
    else { 
        Write-WCLog -Level debug -Message "Policy: $PolicyName, Value: $($pol.Value), returning it back to caller"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $pol.Value #return policy value
    }
}

# --------------------------------------------------------------------------------
# This function will return Event Audit Policy based on given policy name string
# --------------------------------------------------------------------------------
Function Get-WCLSPEventAuditPolicy([string]$PolicyName) {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
    if(-not (Test-WCLSPXMLVariable)) {
        Write-WCLog -Level error -Message "LSP XML data not generated. Cannot get policy value"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $null
    }
    $pol = $Script:PXml.WCLocalSecurityPolicyInfo.EventAudit.policy | where {$_.Name -eq $PolicyName}
    Write-WCLog -Level debug -Message "Value for policy $PolicyName is $($pol.Value)"

    if($pol.count -eq 0) { 
        Write-WCLog -Level debug -Message "Policy $PolicyName, policy not found in xml"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $null 
    } 
    else {
        Write-WCLog -Level debug -Message "Policy: $PolicyName, Value: $($pol.Value), returning it back to caller"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $pol.Value #return policy value
    }
}

# --------------------------------------------------------------------------------
# This function will return Kerberos Policy based on given policy name string
# --------------------------------------------------------------------------------
Function Get-WCLSPKerberosPolicy([string]$PolicyName) {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
    if(-not (Test-WCLSPXMLVariable)) {
        Write-WCLog -Level error -Message "LSP XML data not generated. Cannot get policy value"
        return $null
    }
    $pol = $Script:PXml.WCLocalSecurityPolicyInfo.Kerberos.policy | where {$_.Name -eq $PolicyName}
    Write-WCLog -Level debug -Message "Value for policy $PolicyName is $($pol.Value)"

    if($pol.count -eq 0) { 
        Write-WCLog -Level debug -Message "Policy $PolicyName, policy not found in xml"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $null 
    } 
    else {
        Write-WCLog -Level debug -Message "Policy: $PolicyName, Value: $($pol.Value), returning it back to caller"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $pol.Value #return policy value
    }
}


# -------------------------------------------------------------------------------------
# This function will return Privilege Rights Policy based on given policy name string
# -------------------------------------------------------------------------------------
Function Get-WCLSPPrivilegeRightsPolicy([string]$PolicyName, [switch]$ConvertSidToName) {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
    if(-not (Test-WCLSPXMLVariable)) {
        Write-WCLog -Level error -Message "LSP XML data not generated. Cannot get policy value"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $null
    }
    # get a maching policy node in LSP XML to get its policy value
    $pol = $Script:PXml.WCLocalSecurityPolicyInfo.PrivilegeRights.policy | where {$_.Name -eq $PolicyName}

    if($pol.count -eq 0) { 
        Write-WCLog -Level debug -Message "Policy $PolicyName, value is not defined (policy value is blank so it doesnt appear in secedit/lspxml"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return 'NotDefined'  # return it for policies that have blank values
    } 
    else {
        Write-WCLog -Level debug -Message "Policy: $PolicyName, Value: $($pol.Value)"
        if($ConvertSidToName) { 
            Write-WCLog -Level debug -Message "parameter to get policy name from sid is given"
            $namesArray = New-Object System.Collections.ArrayList

            Write-WCLog -Level debug -Message "Enumerating thru all policy values and getting their names"
            foreach($sid in $pol.Value.Split(",")) {
                $n = Get-SIDToUserName -SIDValue ($sid.replace('*','')) #get sid to name
                Write-WCLog -Level debug -Message "Sid $sid = $n"
                $namesArray.Add($n) | out-null # add it to array
            }
            Write-WCLog -Level debug -Message "Returning array of values after converting Sid to names"
            #return ($namesArray -join ",") # return as comma separated item
            Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
            return ($namesArray | sort) # return sorted array of converted names
        } 
        else { 
            Write-WCLog -Level debug -Message "Policy: $PolicyName, Value: $($pol.Value), returning it back to caller"
            Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
            return $pol.Value  
        } #return policy value, without converting sid to name
    }
    Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
}

# ----------------------------------------------------------------------------------
# This function will return Registry Values Policy based on given policy name string
# example: RestrictAnonymousSAM
# ----------------------------------------------------------------------------------
Function Get-WCLSPRegistryValuesPolicy([string]$PolicyName) {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
    if(-not (Test-WCLSPXMLVariable)) {
        Write-WCLog -Level debug -Message "LSP XML data not generated. Cannot get policy value"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $null
    }
    # For Registry values, parsing would be different as it is not simply a name=value pair
    #policy is in registry path format, get last string after last \ which is policy name
    Write-WCLog -Level debug -Message "Trying to get policy value for $PolicyName"
    $pol = $Script:PXml.WCLocalSecurityPolicyInfo.RegistryValues.policy | where {(($_.Name -split '\\')[-1]) -eq $PolicyName}
    
    if($pol.count -eq 0) { 
        Write-WCLog -Level debug -Message "Policy: $PolicyName, policy not found in xml"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $null 
    } 
    else {
        Write-WCLog -Level debug -Message "Policy: $PolicyName, Value: $($pol.Value), returning it back to caller"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $pol.Value #return policy value
    }
}

# ----------------------------------------------------------------------------------
# This function will return Registry Values Policy based on given policy full line
# example: MACHINE\System\CurrentControlSet\Control\Lsa\RestrictAnonymousSAM
# Required for: There are certain policies that have different path but same name.
# ----------------------------------------------------------------------------------
Function Get-WCLSPRegistryValuesPolicyByFullName([string]$PolicyName) {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
    if(-not (Test-WCLSPXMLVariable)) {
        Write-WCLog -Level debug -Message "LSP XML data not generated. Cannot get policy value"
        Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $null
    }
    # For Registry values, parsing would be different as it is not simply a name=value pair
    # Match for exact policy name, that is essentially a registry path
    Write-WCLog -Level debug -Message "Trying to get policy value for $PolicyName"
    $pol = $Script:PXml.WCLocalSecurityPolicyInfo.RegistryValues.policy | where {$_.Name -eq $PolicyName}
    
    if($pol.count -eq 0) { 
        Write-WCLog -Level debug -Message "Policy: $PolicyName, policy not found in xml"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
        return $null 
    } 
    else {
        Write-WCLog -Level debug -Message "Policy: $PolicyName, Value: $($pol.Value)"
        if($pol.Type -eq 'REG_SZ') { # this is string, if it has double quotes then remove it
            Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
            return ($pol.Value).Replace('"','') #return string value without quotes
        }
        elseif($pol.Type -eq 'REG_MULTI_SZ' -and $pol.Name -notlike '*\LegalNoticeText') { 
            # if it is multi-value string and it is not LegalNoticeText policy, then return an array
            Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
            return ($pol.Value).Split(",")
        }
        else { # this is other than above two types of policy, return value as-is
            Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
            return $pol.Value #return policy value
        }
    }
    Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level debug
}

#endregion LSPPolicyReaderFunctions

#region AdvancedAuditPolicyFunctions

# ----------------------------------------------------------------------------
# This function will return Advanced Audit Policy settings in following format
# Subcategory (Name in xml), Setting (Value in xml), Category (Type in xml)
# ----------------------------------------------------------------------------
Function Get-WCLSPAdvAuditPol {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    
    # run auditpol command to get all policies
    Write-WCLog -Level info -Message "Running auditpol.exe command to get advanced audit policy settings"
    $auditPolData = auditpol /get /category:*
    $category = "" #indicate that category is initially blank
    
    Write-WCLog -Level info -Message "Enumerating thru all advanced audit policy settings"
    foreach($pline in $auditPolData) {
        if($pline.length -ne 0) { # this is non-blank line, process it
            if($pline[0] -ne ' ') { # this is category line, that strat without spaces
                $category = $($pline.trim())
                Write-WCLog -Level debug -Message "Category: $category"
            }
            else { # this is a subcategory setting
                $pline = $pline.trim() -replace '  +',',' # remove extra whitespaces around
                Write-WCLog -Level debug -Message "Processing: $pline"
                $spline = $pline.split(",") # split it on comma
                # output in Subcategory (Name in xml), Setting (Value in xml), Category (Type in xml) format
                $($spline[0]) + ',' + $($spline[1]) + ',' + $category
                Write-WCLog -Level debug -Message ("(Policy Name, Setting, Category) = {0}, {1}, {2}" -f $spline[0],$spline[0], $category)
            }
        }
    }
    Write-WCLog -Level debug -Message "Finished processing advanced audit policies"
    Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
}

# ----------------------------------------------------------------------------
# This function will Convert security policy from System Access area of Local 
# Security Policy into WC Internal Node structure for lookup/reference 
# ----------------------------------------------------------------------------
Function Convert-WCLSPAdvAuditPolToXML {
[CmdletBinding()]
param([string]$WCLSPStructureFile, [string]$LSPAreaName)
    # Note: $LSPAreaName value MUST match the node name in XML file $WCLSPStructureFile
    # Note: Format: $xml.WCLocalSecurityPolicyInfo.$LSPAreaName.Policy

    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    Write-WCLog -Level info -Message "LSP area to export is $LSPAreaName"
    Write-WCLog -Level info -Message "Reading LSP node structure file $WCLSPStructureFile"
    
    # Read contents of node structure file in XML format
    [XML]$xml = Get-Content $WCLSPStructureFile
    Write-WCLog -Level debug -Message "Finished reading WC LSP node structure into a variable"

    # Get advanced audit policies
    Write-WCLog -Level info -Message "Calling Get-WCLSPAdvAuditPol function to get all policies"
    $advAuditPols = Get-WCLSPAdvAuditPol

    # loop thru the LSP data for given area
    Write-WCLog -Level debug -Message "Enumerating thru all policies"
    foreach($cp in $advAuditPols) {
        Write-WCLog -Level debug -Message "Processing: $cp"
        Write-WCLog -Level debug -Message "Cloning $LSPAreaName policy node"
        # use @() to get an array.. to ensure we can index into [0] even if Policy area is empty
        $clNode = @($xml.WCLocalSecurityPolicyInfo.$LSPAreaName.Policy)[0].CloneNode($true)
        
        # assign values to policy node
        Write-WCLog -Level debug -Message "Assigning policy values to cloned node"
        $cpArray = $cp.split(",") # split current policy on comma
        $clNode.Name = $cpArray[0]
        $clNode.Value = $cpArray[1]
        $clNode.Type = $cpArray[2]
        Write-WCLog -Level debug -Message ("Setting: policy name={0}, value={1}, type={2}" -f $clNode.Name, $clNode.Value, $clNode.Type)
        
        # append the node back to xml after update
        Write-WCLog -Level debug -Message "Appending current policy node to xml"
        $xml.WCLocalSecurityPolicyInfo.$LSPAreaName.AppendChild($clNode) | Out-Null
    }

    # remove blank node that was used for cloning purpose
    if($xml.WCLocalSecurityPolicyInfo.$LSPAreaName.Policy.Count -gt 0) {
        Write-WCLog -Level debug -Message "Removing blank policy node used for cloning purposes"
        $xml.WCLocalSecurityPolicyInfo.$LSPAreaName.RemoveChild($xml.WCLocalSecurityPolicyInfo.$LSPAreaName.Policy[0]) | Out-Null
    }
    # done processing, return the updated xml data back
    Write-WCLog -Level debug -Message "Policies added to XML node structure, returning it back to caller"
    Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    return $xml
}

# ------------------------------------------------------------------------------------------
# This function will return policy setting for given advanced audit policy subcategory name
# ------------------------------------------------------------------------------------------
Function Get-WCLSPAdvAuditPolSubCategoryValue([string]$SubcategoryName, [switch]$FullPolicyLine) {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    if(-not (Test-WCLSPXMLVariable)) {
        Write-WCLog -Level error -Message "LSP XML data not generated. Cannot get policy value"
        return $null
    }
    # Match for exact subcategory name
    #Write-WCLog -Level debug -Message "Subcategory name: $SubcategoryName"
    #Write-WCLog -Level debug -Message "Full policy line: $FullPolicyLine"
    $pol = $Script:PXml.WCLocalSecurityPolicyInfo.AdvancedAuditPol.policy | where {$_.Name -eq $SubcategoryName}

    if($pol.count -eq 0) { 
        #Write-WCLog -Level debug -Message "Subcategory: $SubcategoryName, policy not found in xml"
        Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
        return $null 
    } 
    else {
        #Write-WCLog -Level debug -Message "Subcategory: $SubcategoryName, Value: $($pol.Value), Category: $($pol.Type)"
        if($FullPolicyLine) { # return complete line with policy category, subcategory and setting
            #Write-WCLog -Level info -Message "Policy: $($pol.Name), Value: $($pol.Value), Type: $($pol.Type), returning it back to caller"
            Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
            return $Pol.Type + ':' + $pol.Name + ' - ' + $pol.Value 
        } 
        else { # just return policy value
            #Write-WCLog -Level info -Message "Returning full policy value as $($pol.value)"
            Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
            return $pol.Value 
        } 
    }
}
#endregion AdvancedAuditPolicyFunctions

#region ReadLSPIntoXMLForQueryingPurposes
Function Set-WCLSPForQuery {
    Add-Indent -Header ("enter -> {0}" -f $MyInvocation.MyCommand.Name) -Level info

    # create WC node structure
    Write-WCLog -Level info -Message "Creating WCLSP XML file"
    $WCNodeStructFile = New-WCLSPIntrenalStructure
    Write-WCLog -Level info -Message "WCLSP XML file is $WCNodeStructFile"

    # export LSP to a file
    Write-WCLog -Level info -Message "Exporting LSP into a temporary file"
    $lspFile = Export-WCLocalSecurityPolicy
    Write-WCLog -Level info -Message "LSP exported to $lspFile"
    

    # Process SystemAccess area data
    Write-WCLog -Level info -Message "Processing SystemAccess area"
    $lspSystemAccessData = Get-WCLocalSecurityPolicyArea -LSPExportFile $lspFile -LSPAreaName "[System Access]" 
    [xml]$x2 = Convert-WCLSPAreaToXML -LSPData $lspSystemAccessData -WCLSPStructureFile $WCNodeStructFile -LSPAreaName "SystemAccess"
    #$x2.Save($WCNodeStructFile)
    $wcnsfile = [System.IO.File]::CreateText($WCNodeStructFile)
    $x2.Save($wcnsfile)
    $wcnsfile.Close() # close the file after writing

    # Process Privilege Rights area data
    Write-WCLog -Level info -Message "Processing PrivilegeRights area"
    $lspPrivilegeRightsData = Get-WCLocalSecurityPolicyArea -LSPExportFile $lspFile -LSPAreaName "[Privilege Rights]" 
    [xml]$x2 = Convert-WCLSPAreaToXML -LSPData $lspPrivilegeRightsData -WCLSPStructureFile $WCNodeStructFile -LSPAreaName "PrivilegeRights" 
    #$x2.Save($WCNodeStructFile)
    $wcnsfile = [System.IO.File]::CreateText($WCNodeStructFile)
    $x2.Save($wcnsfile)
    $wcnsfile.Close() # close the file after writing

    # Process RegistryValues area data
    Write-WCLog -Level info -Message "Processing RegistryValues area"
    $lspRegistryValuesData = Get-WCLocalSecurityPolicyArea -LSPExportFile $lspFile -LSPAreaName "[Registry Values]" 
    [xml]$x2 = Convert-WCLSPAreaToXML -LSPData $lspRegistryValuesData -WCLSPStructureFile $WCNodeStructFile -LSPAreaName "RegistryValues" 
    #$x2.Save($WCNodeStructFile)
    $wcnsfile = [System.IO.File]::CreateText($WCNodeStructFile)
    $x2.Save($wcnsfile)
    $wcnsfile.Close() # close the file after writing

    # Process EventAudit area data
    Write-WCLog -Level info -Message "Processing EventAudit area"
    $lspEventAuditData = Get-WCLocalSecurityPolicyArea -LSPExportFile $lspFile -LSPAreaName "[Event Audit]" 
    [xml]$x2 = Convert-WCLSPAreaToXML -LSPData $lspEventAuditData -WCLSPStructureFile $WCNodeStructFile -LSPAreaName "EventAudit"
    #$x2.Save($WCNodeStructFile)
    $wcnsfile = [System.IO.File]::CreateText($WCNodeStructFile)
    $x2.Save($wcnsfile)
    $wcnsfile.Close() # close the file after writing
	
	# Process Kerberos area data
    Write-WCLog -Level info -Message "Processing Kerberos area"
    $lspKerberosData = Get-WCLocalSecurityPolicyArea -LSPExportFile $lspFile -LSPAreaName "[Kerberos Policy]" 
    [xml]$x2 = Convert-WCLSPAreaToXML -LSPData $lspKerberosData -WCLSPStructureFile $WCNodeStructFile -LSPAreaName "Kerberos"
    #$x2.Save($WCNodeStructFile)
    $wcnsfile = [System.IO.File]::CreateText($WCNodeStructFile)
    $x2.Save($wcnsfile)
    $wcnsfile.Close() # close the file after writing

    # Process advanced audit pol data
    Write-WCLog -Level info -Message "Processing AdvancedAuditPol data"
    [xml]$x2 = Convert-WCLSPAdvAuditPolToXML -WCLSPStructureFile $WCNodeStructFile -LSPAreaName "AdvancedAuditPol" 
    #$x2.Save($WCNodeStructFile)
    $wcnsfile = [System.IO.File]::CreateText($WCNodeStructFile)
    $x2.Save($wcnsfile)
    $wcnsfile.Close() # close the file after writing

    # Set policy xml data into variable. All queries will use this variable for lookup
    Set-WCLSPXMLVariable -PolicyXMLFile $WCNodeStructFile

    Remove-Indent -Footer ("exit  -> {0}" -f $MyInvocation.MyCommand.Name) -Level info
    # return the file name that holds LSP in XML format for further reference
    return $WCNodeStructFile
}
#endregion ReadLSPIntoXMLForQueryingPurposes