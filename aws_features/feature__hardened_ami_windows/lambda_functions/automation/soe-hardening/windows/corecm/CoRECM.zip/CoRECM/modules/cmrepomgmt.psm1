# This script module contains classes related to managing corecm repository 
# Name   : cmrepomgmt.psm1
# Author : Hari GN
# Team    : Platform x86 CoRE
# Date   : 17-Jul-2018

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 5.0
###################################################################################################################
class CoRECMInventory {

    #region Properties
    #----------------------------------------
    $Name = $Null; #Name of the Inventory
    hidden $CoRECMRepo = $Null; #CoRECM Repository associated with this Inventory
    [pscustomObject[]] $Groups = $Null;  #To hold the Groups in this Inventory
    [pscustomObject[]] $Hosts = $Null; #To Hold the Hosts in this Inventory
    hidden $ReadOnly = $True; #Attribute that decides whether the Inventory is connected in ReadOnlyMode or Update Mode
    #endregion
    
    ###############################################################################################################

    #region constructor

    #----------------------------------------
    #Contructor with only CoRECM Repo
    #----------------------------------------
    CoRECMInventory([string]$CoRECMRepo) {
        
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Test Repo Read Access
        $returnVal = [pscustomobject]($this.TestCMRepoAccess($CoRECMRepo, $True))
        if($returnVal.MessageType -eq "info") {

            $this.CoRECMRepo = $CoRECMRepo; #Update Repo
            
        }

        #Write error if applicable
        if($returnVal.MessageType -eq "error" ) {
            Write-Error $returnVal.Message
        }
    }

    #----------------------------------------
    #Contructor with CoreCM Repo and ReadOnly
    #----------------------------------------
    CoRECMInventory([string]$CoRECMRepo,[boolean]$ReadOnly) {
        
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Test Repo access, Write Access if provided by User
        $returnVal = [pscustomobject]($this.TestCMRepoAccess($CoRECMRepo, $ReadOnly))
        if($returnVal.MessageType -eq "info") {

            $this.CoRECMRepo = $CoRECMRepo; #Update Repo
            $this.ReadOnly = $ReadOnly;# Update ReadOnly Attrib

        }

        #Write error if applicable
        if($returnVal.MessageType -eq "error" ) {
            Write-Error $returnVal.Message
        }
    }

    #----------------------------------------
    #Contructor with three Parameters
    #----------------------------------------
    CoRECMInventory([string]$CoRECMRepo, [boolean]$ReadOnly, [string]$InventoryName) {
        
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Test Repo Access, Test Write Access if applicable
        $returnVal = [pscustomobject]($this.TestCMRepoAccess($CoRECMRepo, $ReadOnly))
        if($returnVal.MessageType -eq "info") {

            $this.CoRECMRepo = $CoRECMRepo; #Update Repo
            $this.ReadOnly = $ReadOnly;# Update ReadOnly Attrib

            if($InventoryName) {
                #Check whether Inventory already exists
                if(Test-Path "$($this.CoRECMRepo)\inventory\$InventoryName\$($InventoryName).JSON") {
                    #read the Inventory and Build the Object with the  inventory
                    $returnVal = [pscustomobject]($this.BuildInventory($InventoryName)) #Build Inventory Object with Groups and Hosts
                }
            }
        }

        #Write error if applicable
        if($returnVal.MessageType -eq "error" ) {
            Write-Error $returnVal.Message
        }
    }
    #endregion
    
    ###############################################################################################################

    #region Common Functions
    #----------------------------------------
    #Function to test CoRECMRepo Access
    #----------------------------------------
    [pscustomobject] TestCMRepoAccess([string]$RepositoryLocation,[boolean]$ReadOnly = $True) {

        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }
        try {
            #check to see a connection can be established to RepositoryLocation
            if((Test-Path "$RepositoryLocation\CoRECM") -eq $false) { 
                $returnVal.MessageType = "error";
                $returnVal.Message =  "Unable to connect to specified CM Repo Location: $RepositoryLocation" 
            }
            else {
		        #check to see if we have write access to the share
                if($ReadOnly -eq $False) {
                    #create a file to verify write access
                    $wcTime = (date).ToString('MMddyyhhmmss');
                    New-Item -ItemType File -Path "$RepositoryLocation\wcrepotest_$wcTime.txt" -ErrorAction SilentlyContinue | Out-Null
                
                    if((Test-Path "$RepositoryLocation\wcrepotest_$wcTime.txt") -eq $false) {
                    
                        $returnVal.MessageType = "error";
                        $returnVal.Message =  "Unable to write to CoRECM Repo.Check Repo permissions";

                    }
			        else {
                        #remove the test file
				        Remove-Item "$RepositoryLocation\wcrepotest_$wcTime.txt" -Force
			        }
                }
            }
        }
        catch {
            $returnVal.MessageType = "error";
            $returnVal.Message =  "$($_.Exception.Message)"
        } 
        return $returnVal; 
    }
    #endregion

    ###############################################################################################################

    #region functions related to inventory
    #----------------------------------------
    #Function to Create a NewInventory
    #----------------------------------------
    [pscustomobject] NewInventory([string]$InventoryName) {

        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {

            #Check whether Inventory already exists
            if(!(Test-Path "$($this.CoRECMRepo)\inventory\$InventoryName\$($InventoryName).JSON") -and !(Test-Path "$($this.CoRECMRepo)\inventory\$InventoryName")) {
				#Create a new Object for Inventory
				New-Item -ItemType Directory -Path "$($this.CoRECMRepo)\inventory\$InventoryName"
                #Copy Template Inventory File
                Copy-Item -Path "$($this.CoRECMRepo)\inventory\template\wcInventory.json" -Destination "$($this.CoRECMRepo)\inventory\$InventoryName\$($InventoryName).JSON"
				#Templatefor ReportHistory
				Copy-Item -Path "$($this.CoRECMRepo)\inventory\template\wcReportHistory.json" -Destination "$($this.CoRECMRepo)\inventory\$InventoryName\ReportHistory.JSON"
                
                $this.Groups = $Null;
                $this.Hosts = $Null;
                $this.Name = $InventoryName;

                $returnVal.Message = "Successfully Created the Inventory"  
                 
            } 
            else {
                $returnVal.MessageType = "error"
                $returnVal.Message = "Inventory with similar name $InventoryName already exists in the repository $($this.CoRECMRepo)"
            } 
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message = "Invalid Operation Repository was opened in ReadOnly Mode"
        } 
        return $returnVal; 
    }
    
    #----------------------------------------
    #Function to list all Inventory
    #----------------------------------------
    [string[]] ListInventory(){
       
        #List  All Inventory in CORECM Repo
        $InventoryList = Get-ChildItem "$($this.CoRECMRepo)\inventory"
        return @($InventoryList.BaseName)

    }
    
    #----------------------------------------
    #Function to Load  an Inventory
    #----------------------------------------
    [pscustomobject] SelectInventory([string]$InventoryName) {

        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Check whether Inventory already exists
        if(Test-Path "$($this.CoRECMRepo)\inventory\$InventoryName\$($InventoryName).JSON") {

            $returnVal = [pscustomobject]($this.BuildInventory($InventoryName)) #Build Object for Selected Inventory
        }
        else {
            $returnVal.MessageType = "error";
            $returnVal.Message = "Inventory $InventoryName doesnt exists"
        }
        return $returnVal; 
    }
    
    #----------------------------------------
    #Function to update Groups/Hosts and create an Inventory object
    #----------------------------------------
    [pscustomobject] BuildInventory([string]$InventoryName) {
        
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        $returnVal = [pscustomobject] ($this.ValidateInventory([string]$InventoryName))
        if($returnVal.MessageType -eq "info") {
            try {
            
                $this.Groups = $Null;
                $this.Hosts = $Null;

                #Read from JSON
                $oJSON =  (Get-Content "$($this.CoRECMRepo)\inventory\$InventoryName\$($InventoryName).JSON") | Convertfrom-JSON

                #Enumerate all the groups and create a new object
                forEach($Group in $oJSON.Groups) {
                    #Create an Object  to hold Group 
                    $oGroup = New-Object CoRECMGroup($Group.Name,$Group.Hosts)
            
                    #Add Group to Inventory
                    $this.Groups +=  $oGroup 
                }
                #Enumearte all Hosts  and create new objects
                forEach($objHost in $oJSON.Hosts) {
                    #Create and Object to hold Host
                    $oHost = New-Object CoRECMHost($objHost.ID, $objHost.Name, $objHost.HostName)
                   					
					#Add Host to Inventory
                    $this.Hosts += $oHost
                }
            
                $this.Name = $InventoryName;
                #update return Variable
                $returnVal.Message = "Successfully Loaded Inventory"
            }
            catch {
                $returnVal.MessageType = "error";
                $returnVal.Message = $_.Exception.Message;
                $this.Groups = $Null;
                $this.Hosts = $Null;
        }
        }
        return $returnVal
    }

    #----------------------------------------
    #Function to validate whether Inventory is accurate
    #----------------------------------------
    [pscustomobject] ValidateInventory([string]$InventoryName){
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }
         try {
           
            #Read from JSON
            $oJSON =  (Get-Content "$($this.CoRECMRepo)\inventory\$InventoryName\$($InventoryName).JSON") | Convertfrom-JSON

            #Check for Multiple Groups with simlar Name
            if(($($oJSON.Groups).Name).Count -ne ($($oJSON.Groups).Name | Select -Unique).Count) {
                $IO = Compare-Object $($oJSON.Groups).Name ($($oJSON.Groups).Name | Select -Unique)
                $returnVal.MessageType = "error";
                $returnVal.Message += "Multiple Group with similar names exits: $(@($IO.InputObject) -join ",");"
            }

            #Check for Multiple hosts with simlar HostName
            if(($($oJSON.Hosts).Name).Count -ne ($($oJSON.Hosts).Name | Select -Unique).Count) {
                $CO = Compare-Object $($oJSON.Hosts).Name ($($oJSON.Hosts).Name | Select -Unique)
                $returnVal.MessageType = "error";
                $returnVal.Message += "Multiple Hosts with similar names exits: $(@($CO.InputObject) -join ",");"
            }

            #Check for Multiple hosts with simlar ID
            if(($($oJSON.Hosts).ID).Count -ne ($($oJSON.Hosts).ID | Select -Unique).Count) {
                $CO = Compare-Object $($oJSON.Hosts).ID ($($oJSON.Hosts).ID | Select -Unique)
                $returnVal.MessageType = "error";
                $returnVal.Message += "Multiple Hosts with similar ID exits: $(@($CO.InputObject) -join ",");"
            }

            #Identify Unresolved Host IDs in Group
            forEach($Group in $oJSON.Groups) {
                $iHostID = $Group.Hosts | Where-Object { $_ -notin @($oJSON.Hosts).ID }
                if($iHostID) {
                    $returnVal.MessageType = "error";
                    $returnVal.Message += "Unresolved HostIDs : $(@($iHostID) -join ",") in Group: $Group"
                }
            }

        }
        catch {
            $returnVal.MessageType = "error";
            $returnVal.Message += $_.Exception.Message;
        }

        return $returnVal;
    }

    #endregion

    ###############################################################################################################

    #region Groups
    #----------------------------------------
    #Function to Add New Group to Inventory
    #----------------------------------------
    [pscustomobject] NewGroup([string]$GroupName) {

        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {
            
            #Check to see Inventory is Already Associated
            if($this.Name -ne $Null) {
                
                #Check to see if group already exists
                $mulGroup = $this.Groups | Where-Object { $_.Name -eq $GroupName }
                
                if($mulGroup) { #if group exists with same name then throw error

                    $returnVal.MessageType = "error"
                    $returnVal.Message =  "Group with similar name $($GroupName) exists in the Inventory"; 

                }
                else {
                    
                    #create New Group Object
                    $oGroup = New-Object CoRECMGroup($GroupName)
                    #Add Group
                    $this.Groups += $oGroup
                    $returnVal.Message = "Successfully Added Group $GroupName to the Inventory";

                }
            }
            else {
                $returnVal.MessageType = "error"
                $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
            }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message =  "Invalid Operation Repository was opened in ReadOnly Mode"
        }
        return $returnVal
    }
    #----------------------------------------
   
    #Function to List all Groups in the inventory
    #----------------------------------------
    [pscustomobject[]] AllGroup() {
        return $this.Groups
    }

    #Function to List all Groups in the inventory
    #----------------------------------------
    [pscustomobject] GetGroup([string]$GroupName) {
        return $this.Groups | Where-Object { $_.Name -eq $GroupName }
    }
    
    #----------------------------------------
    #Function to Rename Group in Inventory
    #----------------------------------------
    [pscustomobject] RenameGroup($GroupName,$NewName) {
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

         #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {

            if($this.Name -ne $Null) {

                if($GroupName.Length -gt 1 -and $NewName.Length -gt 1) {
                    #Identify the Group
                    $oGroup = $this.GetGroup($GroupName)

                    if($oGroup) { 
                        #Rename the Group
                        $oGroup.Name = $NewName;
                        $returnVal.Message = "Successfully Renamed the Group $GroupName to $NewName"
                    } 
                    else {
                        $returnVal.MessageType = "error"
                        $returnVal.Message = "Group $GroupName doesnt exists in this inventory"
                    }
                }
                else{
                    $returnVal.MessageType = "error"
                    $returnVal.Message = "Invalid GroupName" 
                }
            }                      
            else {
                    $returnVal.MessageType = "error"
                    $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
                }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message =  "Invalid Operation Repository was opened in ReadOnly Mode"
        }
                
        return $returnVal
    }
    
    #----------------------------------------
    #Function to Remove Group in Inventory
    #----------------------------------------
    [pscustomobject] RemoveGroup($GroupName) {

    #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

         #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {

            if($this.Name -ne $Null) {
                $oGroup = $this.Groups | Where-Object { $_.Name -eq $GroupName }
                if($oGroup) { 
                    $this.Groups = $this.Groups | Where-Object { $_.Name -ne $GroupName }
                    $returnVal.Message = "Successfully Removed the Group $GroupName from the inventory"
                } 
                else {
                    $returnVal.MessageType = "error"
                    $returnVal.Message = "Group $GroupName doesnt exists in this inventory"
                }
            }                      
            else {
                    $returnVal.MessageType = "error"
                    $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
                }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message =  "Invalid Operation Repository was opened in ReadOnly Mode"
        }
                
        return $returnVal
    }
    #endregion Groups

    ###############################################################################################################

    #region Hosts
    #----------------------------------------
    #Function to Add New Hosts to Inventory
    #----------------------------------------
    [pscustomobject] NewHost([string[]]$HostName) {

        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {
            #Check to see Inventory is Already Associated
            if($this.Name -ne $Null) {

                #Hosts that already exists in invnentory
                $mulHosts = $HostName | Where-Object { $_ -in @($($this.Hosts).Name) }
                
                #Hosts to be added to inventory
                $hoststoAdd = $HostName | Where-Object { $_ -notin @($($this.Hosts).Name) -and $_.Length -gt 1 }

                #Add Hosts to Inventory
                forEach($objHost in $hoststoAdd) {

                    #Genearete Random ID for Host 
                    $ID = Get-Random -Maximum 100000 -Minimum 1000
                    While($ID -in @($($this.Hosts).ID)) {
                        $ID = Get-Random -Maximum 100000 -Minimum 1000
                    }
                    #create an Object for class Host
                    $oHost = New-Object CoRECMHost($ID,$objHost)
                    $this.Hosts += $oHost
                }

                #if there were duplicate hosts create warning for them
                if($mulHosts) {
                    $returnVal.MessageType = "warning"
                    $returnVal.Message =  "$(@($mulHosts) -join ",") were not added,  as they already part of this Inventory"; 
                }
                else { 
                    $returnVal.Message =  "Successfully Added Hosts $($HostName -join ",") to the Inventory";
                }

            }
            else {
                $returnVal.MessageType = "error"
                $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
            }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message = "Invalid Operation Repository was opened in ReadOnly Mode"
        }
        return $returnVal
    }

    #----------------------------------------
    #Function to Add New Hosts to Inventory
    #----------------------------------------
    [pscustomobject] NewHostIP($HostIP,$HostName) {

        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {
            #Check to see Inventory is Already Associated
            if($this.Name -ne $Null) {
                if($HostIP -like "*.*.*.*"){
                    if($HostIP -notin @($($this.Hosts).Name)) {
                        #Genearete Random ID for Host 
                        $ID = Get-Random -Maximum 100000 -Minimum 1000
                        While($ID -in @($($this.Hosts).ID)) {
                            $ID = Get-Random -Maximum 100000 -Minimum 1000
                        }
                        #create an Object for class Host
                        $oHost = New-Object CoRECMHost($ID,$HostIP,$HostName)
                        $this.Hosts += $oHost
                        $returnVal.Message =  "Successfully Added Host $HostIP  to the Inventory";
                    }
                    else {
                        $returnVal.MessageType = "warning"
                        $returnVal.Message =  "$HostIP is not added,  as they already part of this Inventory"; 
                    }
                }
                else {
                        $returnVal.MessageType = "warning"
                        $returnVal.Message =  "$HostIP is not in correct IP format";
                    }
            }
            else {
                $returnVal.MessageType = "error"
                $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
            }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message = "Invalid Operation Repository was opened in ReadOnly Mode"
        }
        return $returnVal
    }
    
    #----------------------------------------
    #Function to Add Hosts to Group
    #----------------------------------------
    [pscustomobject] AddHoststoGroup([string]$GroupName, [string[]]$HostNames) {
       
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }
        
        #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {
            #Check to see Inventory is Already Associated
            if($this.Name -ne $Null) {
                #Check to see if group exists
                $oGroup = $this.Groups | Where-Object { $_.Name -eq $GroupName } 
                if($oGroup) {
                    #Add Hosts to Group
                    $returnVal =[pscustomobject] ($oGroup.AddHost($HostNames,$this.Hosts))
                }
                else {
                    $returnVal.MessageType = "error"
                    $returnVal.Message =  "Group $GroupName doesnt exists in this inventory"
                }
            }
            else {
                $returnVal.MessageType = "error"
                $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
            }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message = "Invalid Operation Repository was opened in ReadOnly Mode"
        }
        return $returnVal;
    }
    
    #----------------------------------------
    #Function to remove Hosts from a Group
    #----------------------------------------
    [pscustomobject] RemoveHostsfromGroup([string]$GroupName, [string[]]$HostNames) {
       
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }
        
        #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {
            #Check to see Inventory is Already Associated
            if($this.Name -ne $Null) {

                #Check to see if group exists
                $oGroup = $this.Groups | Where-Object { $_.Name -eq $GroupName } 
                if($oGroup) {
                    #Remove Hosts from Group
                    $returnVal = [pscustomobject] ($oGroup.RemoveHost($HostNames,$this.Hosts))
                }
                else {
                    $returnVal.MessageType = "error"
                    $returnVal.Message =  "Group $GroupName doesnt exists in this inventory"
                }
            }
            else {
                $returnVal.MessageType = "error"
                $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
            }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message = "Invalid Operation Repository was opened in ReadOnly Mode"
        }
        return $returnVal;
    }

    #----------------------------------------
    #List all Hosts in the Inventory 
    #----------------------------------------
    [pscustomobject] GetHosts() {
        return $this.hosts
    }

    #----------------------------------------
    #List selected Hosts in the Inventory 
    #----------------------------------------
    [pscustomobject] GetHost([string]$HostName) {
        return $this.hosts | Where-Object { $_.Name -eq $HostName }
    }
	
	#----------------------------------------
    #List selected Host by HostName in the Inventory 
    #----------------------------------------
    [pscustomobject] GetHostbyHostName([string]$HostName) {
        return $this.hosts | Where-Object { $_.HostName -eq $HostName }
    }
    
    #----------------------------------------
    #Get HosNames part of Group 
    #----------------------------------------
    [pscustomobject] GetHostNamesinGroup([string]$GroupName) {
        
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Hostnames="";Message=""; }
        
        #Check to see if group exists
        $oGroup = $this.Groups | Where-Object { $_.Name -eq $GroupName } 
        if($oGroup) {
            #Add Get Host Names in Group
            $returnVal = [pscustomobject] ($oGroup.GetHostNames($this.Hosts))
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message =  "Group $GroupName doesnt exists in this inventory"
        }

        return $returnVal;
    }
    
    #----------------------------------------
    #Function to Add Report to Host in Inventory
    #----------------------------------------
    [pscustomobject] AddReport([string]$HostName,[string]$TimeStamp,[string] $ReportType= "Scan",[string]$ReportPath,[string] $LogPath) {

        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {
            #Check to see Inventory is Already Associated
            if($this.Name -ne $Null) {

                #Select the Host
                $oHost = $this.GetHostbyHostName($HostName)

                if($oHost -eq $Null) {
                    $returnVal.MessageType = "error";
                    $returnVal.Message = "Unable to find the host $HostName in Inventory";
                }
                elseif(!(Test-path $ReportPath)) { #check whethe report path is valid
                    $returnVal.MessageType = "error";
                    $returnVal.Message = "ReportPath doesnt exists: $ReportPath";
                }
                else {
                    #Add report to host
                    $Report = New-Object CoRECMReport($TimeStamp, $ReportType, $ReportPath, $LogPath)
					#Add this report into report History JSON
					$ReportPath = "$($this.CoRECMRepo)\inventory\$($this.Name)\ReportHistory.JSON"
					if(Test-Path $ReportPath) {
						#Save the report
						$returnVal = $Report.Save($HostName,$ReportPath)
					}
					else {
						$returnVal.MessageType = "error"
						$returnVal.Message = "ReportHistory.JSON missing in Inventory $($this.Name)"
					}                   
                }
            }
            else {
                $returnVal.MessageType = "error"
                $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
            }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message = "Invalid Operation Repository was opened in ReadOnly Mode"
        }
        return $returnVal
    }
	#Get reports by HostName
	[pscustomobject[]] GetReports([string[]] $HostName = @("All"),$TimeStamp) {
		#customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }
		try {
			$ReportPath = "$($this.CoRECMRepo)\inventory\$($this.Name)\ReportHistory.JSON"
			$reportJSON = Get-Content "$ReportPath" | Convertfrom-JSON 
			$Reports = $Null;
			if($hostName -ne $null) { #FilterByHostName
				if($hostName -eq "All")  { #FilterAll
					$Reports = $reportJSON.ReportHistory
				}
				elseif($hostName.Count -eq 1) { #Use like if one server passed
					$Reports = $reportJSON.ReportHistory | where-Object { $_.HostName -like "*$HostName*" }
				}
				else {
					$Reports = $reportJSON.ReportHistory | where-Object { $_.HostName -in $HostName }
				}
			}
			else { #Get all reports if Null is passed
				$Reports = $reportJSON.ReportHistory
			}
			#Filter by timestamp
			if($TimeStamp.length -gt 0) { #if time stamp is passed filter reports with timestamp
					$Reports | ForEach-Object { $_.Reports = $_.Reports | Where-Object { $_.TimeStamp -like "*$TimeStamp*" }}
			}
			return $Reports
		}
		catch {
			$returnVal.MessageType = "error"
			$returnVal.Message = $($_.Exception.Message)
		}
		return $returnVal
	}
     #----------------------------------------
    #Function to Rename Group in Inventory
    #----------------------------------------
    [pscustomobject] RenameHost($HostName,$NewName) {
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

         #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {

            if($this.Name -ne $Null) { #Inventory Associated ?

                if($HostName.Length -gt 1 -and $NewName.Length -gt 1) { #Input parameters are correct

                    $oHost = $this.GetHost($HostName)

                    if($oHost) {  #Rename Host
                        $oHost.Name = $NewName;
                        $returnVal.Message = "Successfully Renamed the Host $HostName to $NewName"
                    } 
                    else {
                        $returnVal.MessageType = "error"
                        $returnVal.Message = "Host $HostName doesnt exists in this inventory"
                    }
                }
                else{
                    $returnVal.MessageType = "error"
                    $returnVal.Message = "Invalid GroupName" 
                }
            }                      
            else {
                    $returnVal.MessageType = "error"
                    $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
                }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message =  "Invalid Operation Repository was opened in ReadOnly Mode"
        }
                
        return $returnVal
    }
    
    #----------------------------------------
    #Function to Remove Group in Inventory
    #----------------------------------------
    [pscustomobject] RemoveHost($HostName) {

    #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

         #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {

            if($this.Name -ne $Null) {
                #Identify Host
                $oHost = $this.GetHost($HostName)
                
                if($oHost) { 
                   
                    #Identify groups where this Host is part of
                    $oGroups = $this.Groups | Where-Object { $oHost.ID -in $_.Hosts }

                    #Remove Hosts from all groups
                    ForEach($oGrp in $oGroups) { 
                        $returnVal_remove = $this.RemoveHostsfromGroup($oGrp.Name, $HostName) 
                        #If return Val contains error then update the return Valueas applicable
                        if($returnVal_remove.MessageType -eq "error") {
                            $returnVal.MessageType = "error";
                            $returnVal.Message += $returnVal_remove.Message
                        }
                    }

                    #Remove Host should be done once removed from groups
                    $this.Hosts = $this.Hosts | Where-Object { $_.Name -ne $HostName }
                    #Return Succesfull as applicable
                    if($returnVal.MessageType -ne "error") {
                        $returnVal.Message = "Successfully Removed the Host $HostName"
                    }

                } 
                else {
                    $returnVal.MessageType = "error"
                    $returnVal.Message = "Host $HostName doesnt exists in this inventory"
                }
            }                      
            else {
                    $returnVal.MessageType = "error"
                    $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
                }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message =  "Invalid Operation Repository was opened in ReadOnly Mode"
        }
                
        return $returnVal
    }
    #endregion
    
    ###############################################################################################################

    #region saveInventory
    [pscustomobject] SaveInventory() {
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Act Only if ReadOnly is False
        if($this.ReadOnly -eq $False) {
            #Check to see Inventory is Already Associated
            if($this.Name -ne $Null) {
                try {
                    $path = "$($this.CoRECMRepo)\inventory\$($this.name)\$($this.name).JSON"
                    #save the object to JSON
                    $this | Convertto-JSON -Depth 7 | Out-File $path
                    $returnVal.Message = "Successfully Updated the Inventory"
                }
                catch {
                    $returnVal.MessageType = "error"
                    $returnVal.Message = $($_.Exception.Message)
                }
            }
            else {
                $returnVal.MessageType = "error"
                $returnVal.Message = "Inventory is not associated for this action.Please select and Inventory to proceed.";
            }
        }
        else {
            $returnVal.MessageType = "error"
            $returnVal.Message =  "Invalid Operation Repository was opened in ReadOnly Mode"
        }
        return $returnVal;
    } 
    #endregion
      
    ###############################################################################################################
       
}
###################################################################################################################

###################################################################################################################
class CoRECMGroup {

    #region properties

    [string] $Name= $Null; #Hold the Group Name
    [int[]] $Hosts = @(); #Hold the Hosts in the group

    #endregion

    ###############################################################################################################

    #region Contructor
    CoRECMGroup([string]$Name) {
        $this.Name = $Name;
    }
    CoRECMGroup([string]$Name,$Hosts) {
        $this.Name = $Name;
        $this.Hosts = $Hosts;
    }
    #endregion Contructor

    ###############################################################################################################

    #region Common Functions
    #-----------------------------------
    #Function to Add Hosts to Groups
    #-----------------------------------
    [pscustomobject] AddHost([string[]] $HostNames,[pscustomobject] $oHost) {
        
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Identify if there are any unknown hosts
        $failedHosts = $HostNames | Where-Object  { $_ -notin @($oHost.Name) } 

        if(!($failedHosts)) {
            #Identify Known Hosts
            $resolvedHosts = $oHost | Where-Object { $_.Name -in $HostNames }

            # Add Host ID to Group
            forEach($iHost in $resolvedHosts) {
                if($this.Hosts -notcontains $iHost.ID) { #validate if host ID is already present
                    $this.Hosts += $iHost.ID
                }
            }
            $returnVal.Message = "Successfully Updated Hosts $($HostNames -join ",") to Group $($this.Name)";   
        }
        else { 
            $returnVal.MessageType = "error"
            $returnVal.Message =  "Few of the hosts are not added to the inventory $($failedHosts -join ",").NoAction Taken";
        }
        return $returnVal;
    }

    #-----------------------------------
    #Function to remove hosts from Group
    #-----------------------------------
    [pscustomobject] RemoveHost([string[]] $HostNames,[pscustomobject] $oHost) {
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }

        #Identify if there are any unknown hosts
        $failedHosts = $HostNames |  Where-Object { $_ -notin @($oHost.Name) }
        
        if(!($failedHosts)) {
            #Identify Known Hosts
            $resolvedHosts = $oHost | Where-Object { $_.Name -in $HostNames }

            # Remove Hosts to Group
            forEach($ihost in $resolvedHosts) {
                if($this.Hosts -contains $iHost.ID) { #remove if applicable
                    $this.Hosts = $this.Hosts | Where-Object { $_ -ne $iHost.ID }
                }
            
                $returnVal.Message = "Successfully Removed Hosts $($HostNames -join ",") from Group $($this.Name)"; 
            }  
        }
        else { 
            $returnVal.MessageType = "error";
            $returnVal.Message =  "Few of the hosts are not part of this inventory $($failedHosts -join ",").NoAction Taken";
        }
        return $returnVal;
    }

    #-----------------------------------
    #Function to GetHostNames inside a group
    #-----------------------------------
    [pscustomobject] GetHostNames([pscustomobject] $oHost) {
        #customObject to hold returnVal
        $returnVal = @{MessageType="info";Hostnames="";Message=""; }

        #Identify the unresolved hosts in the group list
        $failedHosts = $this.Hosts | Where-Object { $_ -notin $oHost.ID }

        if(!($failedHosts)) {
            #Identify Succesfull Hosts
            $oSelectedhost = $oHost | Where-Object { $_.ID -in $this.Hosts }
            #Identify hosts that are active
            $returnVal.Hostnames = @(($oSelectedhost | Where-Object { $_.Active -eq $True }).Name)
        }
        else {
            $returnVal.MessageType = "error" 
            $returnVal.Message =  "Error: Few of the hosts ID in the group $($this.Name) didnt not resolve to names: $($failedHosts -join ",")";
        }
        return $returnVal;
    }

    #endregion

    ###############################################################################################################
}
###################################################################################################################

###################################################################################################################
class CoRECMHost {

    #region Properties

    [int] $ID= $Null; #Unique Identifier for the Host
    [string] $Name= $Null; #Name of the Host or IP
    [string] $HostName = $Null; #FriendlyName
    [boolean] $Active = $True; #Is the Host Active

    #endregion

    ###############################################################################################################

    #region Contructor

    CoRECMHost([int]$ID,[string]$Name) {
        $this.Name = $Name;
        $this.ID = $ID;
        $this.HostName = $Name
    }

    CoRECMHost([int]$ID,[string]$Name,[string] $HostName) {
        $this.Name = $Name;
        $this.ID = $ID;
        $this.HostName = $HostName;
    }

    #endregion Contructor

    ###############################################################################################################

    #region Common Functions
    #-----------------------------------
    #Function to DisableHost
    #-----------------------------------
    Disable(){
        $this.Active = $False;
    }
    
    #-----------------------------------
    #Function to EnableHost
    #-----------------------------------
    Enable(){
        $this.Active = $True;
    }
    #endregion

}
###################################################################################################################

###################################################################################################################
class CoRECMReport {

    #region Properties
	[string] $TimeStamp= $Null; #Name for the Report
    [string] $ReportType = "Scan"
    [string] $ReportPath= $Null; #Path where report is stored
	[string] $LogPath= $Null; #Path where report is stored
    #endregion

    ###############################################################################################################

    #region Contructor

    CoRECMReport([string] $TimeStamp,[string] $ReportType,[string] $ReportPath,[string] $LogPath) {
        $this.TimeStamp = $TimeStamp;
        $this.ReportPath = $ReportPath
		$this.LogPath = $LogPath
        $this.ReportType = $ReportType
    }
	
	CoRECMReport([pscustomobject] $Report) {
        $this.TimeStamp = $Report.TimeStamp;
        $this.ReportPath = $Report.ReportPath
		$this.LogPath = $Report.LogPath
        $this.ReportType = $Report.ReportType
    }
	#endregion Contructor
	[pscustomobject] Save($HostName,$ReportPath) {
		#customObject to hold returnVal
        $returnVal = @{MessageType="info";Message=""; }
		try {
			$reportJSON = Get-Content "$ReportPath" | Convertfrom-JSON 
			
			$oHost = $reportJSON.ReportHistory | Where-Object { $_.HostName -eq $HostName }
			
			if($oHost -eq $Null) {
				$currentHost = New-Object pscustomObject;
				$currentHost | Add-Member -MemberType NoteProperty -Name "HostName" -Value $HostName;
				$currentHost | Add-Member -MemberType NoteProperty -Name "Reports" -Value @();
				$reportJSON.ReportHistory += $currentHost
				$oHost = $reportJSON.ReportHistory | Where-Object { $_.HostName -eq $HostName }
			}
			$oHost.Reports += $this
			
			$reportJSON | Convertto-JSON -Depth 7 | Out-File $Reportpath
			$returnVal.Message = "Successfully updated report for specified Host";
		}
		catch {
			$returnVal.MessageType = "error"
			$returnVal.Message = $($_.Exception.Message)
		}
		return $returnVal
	} 
	#function to create a newbaseline out of the  report
	[pscustomobject] CreateBaseline($BaselineName, $NewReportPath) {
		$returnVal = @{MessageType="info";Message=""; }
		try {
			if($BaselineName.Length -lt 5) {
				$returnVal.MessageType = "error"
				$returnVal.Message = "BaselineName should be min 5 characters"
			}
			elseif(Test-Path $this.ReportPath) {
				[xml] $BaselineXML= Get-Content $this.ReportPath
				#Reset LogPath and RSItem
				$BaseLineXML.CoRECM.LogFile.Path = ""
				$BaselineXML.CoRECM.Baseline.CoREInfo.Name = $BaselineName
				($BaselineXML.CoRECM.ReportSummary.RSItem | Where-Object  { $_.Name -ne "ReportName" }) | ForEach-Object { $_.Value = "" }
				#Reset Section Category Count Policy Passed etc
				$BaselineXML.SelectNodes("//Section") | ForEach-Object { $_.CategoryCount = "";$_.PolicyCount = "";$_.Passed = "";$_.Failed = ""; }
				$BaselineXML.SelectNodes("//Category") | ForEach-Object { $_.PolicyCount = "";$_.Passed = "";$_.Failed = ""; }
				
				#Tring to reset Policy Node
				$colPolicy = $BaselineXML.SelectNodes("//Policy") | Where-Object { $_.Processed -eq "True" }
				ForEach($Policy in $colPolicy) {
                    if($Policy.TestResult -eq "Failed") { #Only Failed Policies has to be reverted , rest can hold default value as is
						#create a new node to hold CoRE for Windows Configuration
						$CoREPolicy = $BaselineXML.CreateElement("CoREConfig")
						$CoREPolicy.SetAttribute("Value","")
						
						#clear default value enumeration
						if($Policy.DefaultValue.ValueEnumeration) { 
							$CoREPolicy.InnerXML = $Policy.DefaultValue.InnerXML;
							$Policy.DefaultValue.InnerXML = ""; 
						}
						else {
							$CoREPolicy.Value = $Policy.DefaultValue.Value;
							$Policy.DefaultValue.Value = "";
						}
						$Policy.AppendChild($CoREPolicy)
						
						#Use InnerXML for ValueEnumeration
						if($Policy.CurrentValue.ValueEnumeration) { 
							$Policy.DefaultValue.InnerXML = $Policy.CurrentValue.InnerXML
						}
					    else {
							$Policy.DefaultValue.Value = $Policy.CurrentValue.Value
						}
                    }
					$Policy.CurrentValue.InnerText = ""
					$Policy.CurrentValue.Value = ""
					$Policy.TestResult = ""
					$Policy.Processed = "False"
			
				}
				$BaselineXML.Save($NewReportPath)
				$returnVal.Message = $NewReportPath
			}
			else {
				$returnVal.MessageType = "error"
				$returnVal.Message = "$($this.ReportPath) doesnt exists"
			}
		}
		catch {
			$returnVal.MessageType = "error"
			$returnVal.Message = $($_.Exception.Message)
		}
		return $returnVal
	}
	#function to create a newbaseline out of the  report
	[pscustomobject] GetDelta($ReportXMLFile) {
		$returnVal = @{MessageType="info";Message="";Config=@(); }
		try {
			 [xml] $CurrentReportXML = Get-Content $this.ReportPath
			[xml] $LastScanReportXML = Get-Content $ReportXMLFile
			
			#get current policies and old report policies
			$CurrentPolicies = $CurrentReportXML.SelectNodes("//Policy") | Select Id,@{Name="CurrentValue";Expression = {if($_.CurrentValue.ValueEnumeration) { $_.CurrentValue.ValueEnumeration -join ","; } else { $_.CurrentValue.Value} }}
			$OldReportPolicies = $LastScanReportXML.SelectNodes("//Policy") | Select Id,@{Name="CurrentValue";Expression = {if($_.CurrentValue.ValueEnumeration) { $_.CurrentValue.ValueEnumeration -join ","; } else { $_.CurrentValue.Value} }}
			
			#compare currentValue
			$oCompare = Compare-Object $CurrentPolicies $OldReportPolicies -Property CurrentValue,Id;

			if($oCompare -eq $Null) {
				$returnVal.Message = "No_Config_Change"
			}
			else{
				$PolChanged = $CurrentReportXML.SelectNodes("//Policy") | Where-Object { $_.Id -in $oCompare.Id }
				#create a new report with only policies to consider
				foreach($Pol in $PolChanged) {
					$retPol = @{PolicyID=$Pol.Id;PolicyName=$Pol.PolicyName;DefaultValue="";CurrentValue="";PreviousConfigValue="";}
					#defaultValue
					if($Pol.DefaultValue.ValueEnumeration) { $retPol.DefaultValue = @($Pol.DefaultValue.ValueEnumeration) } 
					else { $retPol.DefaultValue = $Pol.DefaultValue.Value}
					#currentValue
					if($Pol.CurrentValue.ValueEnumeration) { $retPol.CurrentValue = @($Pol.CurrentValue.ValueEnumeration) } 
					else { $retPol.CurrentValue = $Pol.CurrentValue.Value}
					
					#get the currentValue in old config
					$OldReportPol =  $LastScanReportXML.SelectNodes("//Policy") | Where-Object { $_.ID -eq $Pol.Id }
					if($OldReportPol){
						#get the current value from old report
						if($OldReportPol.CurrentValue.ValueEnumeration) { $retPol.PreviousConfigValue = @($OldReportPol.CurrentValue.ValueEnumeration) } 
						else {$retPol.PreviousConfigValue = $OldReportPol.CurrentValue.Value}
					}
					else {
						$retPol.PreviousConfigValue = "Policy doesnt Exists"
					}
					#update returnVariable
					$returnVal.Config += [psCustomObject]$retPol
				}
			}
		}
		catch {
			$returnVal.MessageType = "error"
			$returnVal.Message = $($_.Exception.Message)
		}
		return $returnVal
	}
}
###################################################################################################################


