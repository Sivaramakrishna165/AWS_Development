#Function to Modify Custom build XML
Function Modify-BuildXML($xmlFile,$policyID,$newValue){
    Write-WCLog -Message "[Modify-BuildXML]";
    $orgFile = Get-Item C:\SUPPORT\CoRECM\baseline\userdefined\$xmlFile
    $xmlFile = [xml](Get-Content $orgFile)
    $replaceXML = ($xmlFile.SelectNodes("//Policy") | Where-Object {$_.Id -eq $policyID})
    $replaceXML.DefaultValue.Value = $newValue
    If($replaceXML.DefaultValue.Value -eq $newValue){Write-WCLog -Message "Updated $($policyID) to $($newValue)"}Else{Write-WCLog -Level Error -Message "Failed to Update $($policyID) to $($newValue)##########"}
    $xmlFile.Save($orgFile.FullName)
}

Function Update-Setupcmd([string]$Baseline) {
    Write-WCLog -Message "[Update-Setupcmd]";

    $file = (Get-Item "$baseLine").Name.Split(".")[0]
    Copy-Item $baseLine C:\SUPPORT\CoRECM\baseline\userdefined\$($file)_Cloud.xml
    If(Test-Path  C:\SUPPORT\CoRECM\baseline\userdefined\$($file)_Cloud.xml){Write-WCLog -Message "Successfully copied build template to  C:\SUPPORT\CoRECM\baseline\userdefined\$($file)_Cloud.xml for modification"}Else{Write-WCLog -Level Error -Message "Failed to copy build template for modification##########";Exit 57} 

    #Put custom Cloud Policy modifications here 
    ########################################################
    Write-WCLog -Message "Adding approved CoRECM Baseline file modifications for approved standards deviation (if required)"
	If(Test-Path "C:\Windows\OEM\SetupComplete.cmd"){
        
    }
    Else{
        Modify-BuildXML "$($file)_Cloud.xml" "SO087" "0" #Enable unsigned executables (for example to run amazon ec2launch)
    }
    #Modify-BuildXML "$($file)_Cloud.xml" "RDP015" "0" #Enable RDP Drive Redirection
    #Modify-BuildXML "$($file)_Cloud.xml" "TCP018" "0" #enable ipv6
    #Modify-BuildXML "$($file)_Cloud.xml" "SCM001" "Enabled" #enable ipv6
    ########################################################

    $remediateCMD = "C:\SUPPORT\CORECM\WCRemediation.ps1 -BaselineFile C:\SUPPORT\CoRECM\baseline\userdefined\$($file)_Cloud.xml -RemediateAll -UpdateBranding -Ignorerescan -RelaxSecurityInWorkgroup -Confirm:`$False -OutVariable ccRem"

    #Write-WCLog -Message "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
    #Write-WCLog -Message $remediateCMD
    #Write-WCLog -Message "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"

    Write-WCLog -Message "Looking for setupcomplete.cmd to prepare for any future template activities based on this deployment"

    If(Test-Path "C:\Windows\OEM\SetupComplete.cmd"){
        Write-WCLog -Message "Detected Azure environment. Adjusting SetupComplete Command appropriately so that it will run upon deployment."
        $scCommand = "C:\Windows\OEM\SetupComplete2.cmd"
    }
    Else{
         Write-WCLog -Message "Typicaly expected SetupComplete Command to be used"
   	    $scCommand = "C:\Windows\Setup\Scripts\SetupComplete.cmd"
    }

    Try{
        If(Test-Path $scCommand){
            Write-WCLog -Message "$scCommand found. Modifying with full remediation command established here for future template deployment."
		    Add-Content -Path $scCommand -Value "`n" -Force
            Add-Content -Path $scCommand -Value "powershell $remediateCMD" -Force
        }
        Else{
            Write-WCLog -Message "$scCommand not found. Creating one for full remediation command established here for future template deployment."
            New-Item $scCommand -Force -ItemType File
            Add-Content -Path $scCommand -Value "`npowershell $remediateCMD" -Force
        }
    }
    Catch{
        Write-WCLog -Message "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
        Write-WCLog -Level Error -Message "There was an issue dealing with $scCommand."
        Write-WCLog -Level Error -Message "This paticular instance CAN be remediated and the process will not fail out, but THERE WILL BE POLICY FAILURES IF A TEMPLATE IS CREATED FROM THIS MACHINE"
        Write-WCLog -Message "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
        $miscErrVar = "57"
    }

}