

#Function to read config XML and assign it to a script variable
Function Set-TransferLogFile($TransferType){

    try {
        #Setup Logfolder and LogFile
		$cmTime = $(get-date -format "MM_dd_yyyy_hh_mm_ss")
		$LogFolder  = (Resolve-Path ".\Logs" -ErrorAction SilentlyContinue).Path
		$LogFile = "$LogFolder\Transfer\$($TransferType)_$cmTime.log"
        
        #Create Log Foldre if doesnt exists
		if(!(Test-Path "$LogFolder\Transfer")) { New-Item "$LogFolder\Transfer" -ItemType Directory  | Out-Null }
		
        #Create Log File 
		if((Test-Path $LogFile) -ne $true) {
            New-Item -ItemType File $LogFile -Force | Out-Null;
        }
        $Script:TransferLogFile = $LogFile
    }
    catch { return $_.Exception.Message }
}

# Function to Write messages to the log file
# ------------------------------------------
Function Write-CoRECMTransferLog($Message) { 
    if($Message -ne $NULL) {
        #Write-Warning -Message $Message -Verbose # write all log messages as verbose
        if($script:TransferLogFile -eq $NULL -or ($script:TransferLogFile).length -eq 0) {
            return # no log file given, skip writing to log file
        }
        # if valid log file then write to log file as well
        if(Test-Path $Script:TransferLogFile) {
            Add-Content -Path $Script:TransferLogFile -Value "[$(get-date -format "MM/dd/yyyy hh:mm:ss")] $Message"
        }
    }
}

#Function to read config XML and assign it to a script variable
Function Invoke-CoRECMTransfer($TransferType, [string[]]$FileList){

    try {
		Set-TransferLogFile -TransferType $TransferType 
		#Read Transfer Details for Transfer Type
		$TransferServer = [pscustomobject] (Get-TransferServerConfiguration -TransferType $TransferType) #Get Transfer Server Detail
		
		if(!($TransferServer)) { #if server  details are present
			Write-Warning "Unable to locate configuration in transferconfig.xml for uploading the CoRECM Report."
			return "transfer_config_missing_ESL";
		}
		
		Write-CoRECMTransferLog -Message "CoRECMTransferLog -TransferType $TransferType"
		Write-CoRECMTransferLog -Message "Server $($TransferServer.Server)- User $($TransferServer.User)  - Directory $($TransferServer.Directory)"		

        #$transfermethod should refelect the exe that will be used
		$binPath = (Resolve-Path "$PSScriptRoot\..\bin").Path
		if(!(Test-Path("$PSScriptRoot\..\bin\$($($TransferServer.TransferMethod)).exe"))) {
			Write-Warning "Selected transfer method is $($TransferServer.TransferMethod), but unable to locate but unable to locate $binPath\$($TransferServer.TransferMethod).exe"
			Write-CoRECMTransferLog -Message "Selected transfer method is $($TransferServer.TransferMethod), but unable to locate but unable to locate $binPath\$($TransferServer.TransferMethod).exe"
			return "$($TransferServer.TransferMethod).exe_doesnt_exist_in_bin";
		}
        #Invoke-FileTransfer
		return (Invoke-FileTransfer -FileList $FileList -TransferServer $TransferServer)
    }
    catch { return $_.Exception.Message }
}

Function Invoke-FileTransfer { param($FileList,[pscustomobject] $TransferServer)
	
	try {
		"Y" | Out-File "$binPath\Answer.txt"
        #generate command here	
		$pscpCMD = "cmd.exe /c $binPath\pscp.exe %PPKFILE% %FILE% $($TransferServer.User)@$($TransferServer.Server):$($TransferServer.Directory)  ``< $binPath\Answer.txt"
		$sftpCMD = "cmd.exe /c $binPath\sftp.exe %PPKFILE% $($TransferServer.User)@$($TransferServer.Server):$($TransferServer.Directory) <<< $'put {%FILE%}'"
		$return = ""
		
		#Process PPK File if applicable
		if($TransferServer.PPKFile -like "*.ppk*") {
			$PPKPath = (Resolve-Path ($TransferServer.PPKFile) -ErrorAction SilentlyContinue).Path
			if((Test-Path $PPKPath) -and ((Get-Item $PPKPath).Extension -eq ".ppk")) {
				$pscpCMD = $pscpCMD.replace("%PPKFILE%","-i $PPKPath")
				$sftpCMD = $sftpCMD.replace("%PPKFILE%","-i $PPKPath")
			}
			else {
				Write-CoRECMTransferLog -Message "Unable to locate PPK File $PPKPath"
			}
		}
		else {
			$pscpCMD = $pscpCMD.replace(" %PPKFILE%","") #remove ppk file place holder
			$sftpCMD = $sftpCMD.replace(" %PPKFILE%","") #remove ppk file place holder
		}
		foreach($FileName in $FileList) {
			Write-CoRECMTransferLog -Message "Transferring File $FileName"
			
			if(Test-Path $FileName) {
                #Generate expresison for file transfer
				$exp = ""
				if($TransferServer.TransferMethod -eq "pscp") {
					$exp = $pscpCMD.replace("%FILE%",$FileName) 
				}
				else {
					$exp = $sftpCMD.replace("%FILE",$FileName) #replace place holder with actual file path
				}
				#Launc hthe command
				$result = Invoke-Expression $exp;

				#If 100% is not present in result some file upload has failed
				if(($result -match "100%") -eq $null -or $result -eq $Null) {
					Write-CoRECMTransferLog -Message "File Upload Failed : $FileName" 
					Write-CoRECMTransferLog -Message "$Result"
					$return += "$FileName_"
				}
				else { 
                    
					Write-CoRECMTransferLog -Message "Successfully Uploaded" 
                    
                    #Delete results after ulload if applicable
                    if($TransferServer.DeleteReportsAfterUpload -eq "Yes") {
                        Write-CoRECMTransferLog -Message "Deleting File as DeleteFileAfterUpload is Enabled"
                        Remove-Item $FileName -Force | Out-Null
                    }
				}
			}
			else {
				Write-CoRECMTransferLog -Message "Unable to find $FileName"
				$return += "missing_$FileName"
			}
		}
		Remove-Item "$binPath\Answer.txt" -Force
		if($return.length -gt 0) {
			$return = "Failed_" + $return
		}
		else {
			$return = "Success"
		}
	}
	catch {
		Write-CoRECMTransferLog -Message  "Transfer Failed"
		Write-CoRECMTransferLog -Message $_.Exception.Message;
		$return = "Failed_" + $_.Exception.Message + "_" +  $return
	}
	return $return;
}
Function Get-TransferServerConfiguration($TransferType) {
	
	try {
        
		[pscustomobject] $tServer = @{ Server=""; User = ""; directory = "";TransferType ="";
                    TransferMethod = "";DeleteReportsAfterUpload = ""; }
		
        if(Test-Path (Resolve-Path "$psScriptRoot\..\config\transferconfig.xml").path) {
            #Read the xml
            [xml] $tsXML = Get-Content "$psScriptRoot\..\config\transferconfig.xml"
			$ts = $tsXML.SelectNodes("//Server") | Where-Object { $_.TransferType -eq $TransferType } 
			if($ts) { 
				if((($ts.Server).length -gt 0) -and (($ts.User).length -gt 0) -and (($ts.Directory).length -gt 0)){
					$tServer.Server = $ts.Server
					$tServer.User = $ts.User
					$tServer.Directory = $ts.Directory
					$tServer.TransferType = $ts.TransferType
                    $tServer.TransferMethod = $ts.TransferMethod
                    $tServer.DeleteReportsAfterUpload = $ts.DeleteReportsAfterUpload
					$tServer.PPKFile = $ts.PPKFile
                    #return captured details
					return $tServer
				}
			}
        }
    }
    catch { return $_.Exception.Message }
}